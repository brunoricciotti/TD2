/*
 * Ejemplo de comunicación I2C. Uso de un conversor digital analógico I2C
 * MCP4725. La conexión con el M3 es la siguiente:
 * 	-	SCL -> B5
 *  - 	SDA -> B6
 *  - 	VCC -> 3V3
 *  - 	GND -> G
 *
 *  El programa pone en el DAC los valores de 3V, 2V, 1V y de nuevo 3V cada
 *  4s para poder verlo bien con un tester común.
 *  El DAC es el que se encuentra montado en la placa según
 *  https://learn.adafruit.com/mcp4725-12-bit-dac-tutorial/download
 *
 */

#include "main.h"
#include "miniplanificador.h"
#include "timer_monitor.h"

#define dwt_init() 	{DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk; DWT->CYCCNT=0;}
#define dwt_reset() {DWT->CYCCNT=0;}
#define dwt_read() 	(DWT->CYCCNT)
#define TICKS_SISTEMA		(2)
#define MAX_LEN_TASK_LIST	(4)

I2C_HandleTypeDef hi2c1;
TaskStat lista_tareas[MAX_LEN_TASK_LIST];
int ticks=0;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
int setear_dac(uint32_t valor);
void tarea_dac(void *p);
void tarea_led(void *p);
void falla_sistema(void);

int main(void)
{
	int tc;
	int wcet_todo=0;
	ticks=TICKS_SISTEMA;
	HAL_Init();
	SystemClock_Config();
	MX_GPIO_Init();
	MX_I2C1_Init();
	dwt_init();
	inic_timer();
	inicializar_despachador(lista_tareas, MAX_LEN_TASK_LIST, start_timer, stop_timer, falla_sistema);
	agregar_tarea(lista_tareas, tarea_dac, NULL, 0, 2000, 0, 500);
	agregar_tarea(lista_tareas, tarea_led, NULL, 0, 125, 0, 10);
    while (1)
    {
    	dwt_reset();
    	if(!ticks)
    	{
		  ticks=TICKS_SISTEMA;
		  despachar_tareas();
    	}
    	tc = dwt_read();
    	if(tc>wcet_todo) wcet_todo=tc;
    	/*
    	 * WCET_tarea_dac =	374us
    	 * WCET_tarea_led = 2us
    	 * WCET tareas + despachador = 27567 ciclos de procesador
    	 * 							 = 27567/72e6
    	 * 							 = 383us
    	 */
    }
}

int setear_dac(uint32_t valor)
{
	/*
	 *	Ver http://ww1.microchip.com/downloads/en/DeviceDoc/22039d.pdf
	 *	para los comandos. Básicamente es una escritura de un comando en un
	 *	byte el valor a convertir (12 bits) en otros dos bytes.
	 */
	HAL_StatusTypeDef ret;
	uint8_t datos[3];
	datos[0]=0x40;
	datos[1]=(uint8_t)((valor>>4)&0xFF);
	datos[2]=(uint8_t)((valor&0xF)<<4);
	ret = HAL_I2C_Master_Transmit(&hi2c1, 0x60<<1, datos, 3, 10);
	return (ret == HAL_OK)?0:-1;
}

void tarea_dac(void *p)
{
	static int estado = 0;
	const uint32_t valores[3]={3726, 2483, 1241};
	if(setear_dac(valores[estado++]))
	{
		falla_sistema();
	}
	if(estado==3)estado=0;
}

void tarea_led(void *p)
{
	HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
}


void falla_sistema(void)
{
	__disable_irq();
	while (1)
	{
		for (uint32_t i = 0; i < 100000; i++)
			;
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
	}
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}

static void MX_I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  HAL_I2C_Init(&hi2c1);
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

}
