/*
 *
 * Programa que lee un sensor de temperatura y humedad DHT22 conectado en el pin
 * PB6 del chip (STM32F103C8T6) y envía por línea serie (PA9) a 9600-8-N-1 sin
 * control de flujo. La temperatura y la humedad en formato ASCII como:
 *
 * <TT.TC;HH.H%>\r\n o bien <-TT.TC;HH.H%>\r\n en decimal.
 * <27.1C;68.5%> por ejemplo.
 *
 * La idea de este programa es ver un pequeño proyecto en TDS donde hay que partir
 * tareas para que el Ts no se haga infinito.
 *
 * Juan. 9/6/2020
 *
 */



#include "main.h"
#include <stdio.h>
#include "../tareas/tareas.h"

/*
 * Contador DWT lo uso para estimar los tiempos de las tareas.
 */
#define dwt_init() 	{DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk; DWT->CYCCNT=0;}
#define dwt_reset() {DWT->CYCCNT=0;}
#define dwt_read() 	(DWT->CYCCNT)

UART_HandleTypeDef huart1;
uint32_t ticks = 0;

/*
 * Variables compartidas entre tareas.
 *
 */
uint32_t ret = 0;
int temperatura = 0;
int humedad = 0;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);

uint32_t leer_dht(int *temperatura, int *humedad);
void demora_tics(uint32_t delay);
void enviar_serie(int *temperatura, int *humedad, uint32_t *empezar);
void tarea_dht(void *p);
void tarea_serie(void *p);
void tarea_led(void *p);

int main(void)
{
	HAL_Init();
	dwt_init();
	SystemClock_Config();
	MX_GPIO_Init();
	MX_USART1_UART_Init();

	/*
	 *	El DHT22 tiene una interfaz a través de un
	 *	ÚNICO PIN BIDIRECCIONAL. Para manejarlo configuré
	 *	el PB6 como OPEN DRAIN ya que el DHT22 requiere un Pull-up,
	 *	también es open drain y hay que definirle el uno por afuera
	 *	(le puse 1Kohm).
	 *	Entonces si pongo el pin en 1 el transistor N de la salida
	 *	CMOS está cortado y el DHT puede escribir y el chip leer.
	 *	sin problemas.
	 *
	 */
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);


	/*
	 * Habilito el timer 2 que voy a usar para
	 * generar las demoras del orden de las decenas
	 * de microsegundos (SystemCoreClock 72MHz)
	 */
	__HAL_RCC_TIM2_CLK_ENABLE();

	/*
	 * Para armar este pequeño proyecto con TDS uso el
	 * despachador cooperativo de la clase 4.
	 * "clase4_cooperativo_bluepill.zip"
	 * No es necesario correr en assembler la tarea,
	 * pero como estaba hecho y probado lo uso así.
	 *
	 */

	inicializar_despachador();
	/*
	 *	Como el Ts es de 10ms:
	 *		tarea_led 	se despacha cada 250ms
	 *		tarea_dht 	se despacha cada 10ms
	 *		tarea_serie se despacha cada 10ms
	 */
	agregar_tarea(tarea_led, 25, 0, NULL);
	agregar_tarea(tarea_dht, 1, 0, NULL);
	agregar_tarea(tarea_serie, 1, 0, NULL);

	while (1)
	{
		if (ticks)
		{
			ticks--;
			despachar_tareas();
		}
		/*
		 * No uso el __wfi() [debería]
		 * para simplificar el debug con la bluepill
		 * El usar __wfi me asegura mejor el Ts y me evita
		 * oscilaciones que dependan de la carga de la tarea.
		 *
		 */
	}
}


/*
 * Tarea que encapsula la lectura del DHT22
 * Verificar que no se hace toda la lectura en una
 * sola pasada.
 *
 * WCET medido 292.045 ciclos (4.06ms)
 *
 */
void tarea_dht(void *p)
{
	int x;
	static int wcet_dht = 0;
	dwt_reset();
	ret = leer_dht(&temperatura, &humedad);
	x = dwt_read();
	if (x > wcet_dht)
		wcet_dht = x;
}

/*
 * Tarea que encapsula la función de la transmisión serie.
 * (No se transmite todo en una única pasada)
 *
 * WCET medido de 6.688 ciclos (0.09ms)
 *
 */
void tarea_serie(void *p)
{
	int x;
	static int wcet_ser = 0;
	dwt_reset();
	enviar_serie(&temperatura, &humedad, &ret);
	x = dwt_read();
	if (x > wcet_ser)
		wcet_ser = x;
}

/*
 *
 * Tarea que planifica un led parpadeando.
 * directamente defino el ton como el período de la
 * tarea del led.
 *
 * WCET medido menor a 1us
 *
 */
void tarea_led(void *p)
{
	int x;
	static int wcet_led = 0;
	dwt_reset();
	HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
	x = dwt_read();
	if (x > wcet_led)
		wcet_led = x;
}

/*
 * Uso el timer 2 para generar demoras de tics de clock del procesador
 * del orden de los microsegundos.
 * Tener en cuenta que se ejecuta con un core clock de 72MHz.
 *
 */
void demora_tics(uint32_t delay)
{
	TIM2->ARR = delay;
	TIM2->CR1 = (1 << 4) || (1 << 1) || (1 << 0);
	while (!(TIM2->SR & 0x01))
		;
	TIM2->CR1 &= ~1;
	TIM2->SR &= ~1;
}

/*
 * Función que lee el dht22. Hay que llamarla cada 10ms para
 * que tome la temperatura y humedad cada 2.5s
 *
 * https://www.datasheetq.com/datasheet-download/274274/1/Unspecified/AM2302
 *
 */
uint32_t leer_dht(int *temperatura, int *humedad)
{
	static uint32_t estado = 0;
	static uint64_t buf;
	uint32_t i, j;
	uint32_t chk;
	uint32_t ret;
	uint8_t datos[5];

	ret = 0;
	switch (estado)
	{
	case 246:
		//Bajo el pin para pedir datos.
		buf = 0;
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
		estado++;
		break;
	case 247:
		estado++;
		break;
	case 248:
		//Suelto el pin para empezar a medir.
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);

		//Espero que suba y baje dos veces.
		for (i = 0; i < 2; i++)
		{
			while (!HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6))
				;
			while (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6))
				;
		}

		for (i = 0; i < 40; i++)
		{
			while (!HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6))
				;
			for (j = 0; HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6); j++)
				demora_tics(72 * 2);
			buf <<= 1;
			if (j >= 20)
				buf |= 1;
		}
		estado++;
		break;
	case 249:
		datos[4] = (buf >> 0) & 0xFF;
		datos[3] = (buf >> 8 * 1) & 0xFF;
		datos[2] = (buf >> 8 * 2) & 0xFF;
		datos[1] = (buf >> 8 * 3) & 0xFF;
		datos[0] = (buf >> 8 * 4) & 0xFF;
		chk = 0;
		for (i = 0; i < 4; i++)
			chk += datos[i];
		chk &= 0xff;
		if (chk == datos[4])
		{
			*humedad = (((uint32_t) (datos[0])) << 8) | datos[1];
			*temperatura = (((uint32_t) (datos[2] & 0x7F)) << 8) | datos[3];
			if (datos[2] & 0x80)
				*temperatura = -*temperatura;
			ret = 1;
		}
		estado = 0;
		break;
	default:
		estado++;
	}
	return ret;
}

/*
 * Función que despacha por línea serie a 9600-8-N-1
 * La temperatura y la humedad si el contenido de empezar es 1
 * cuando detecta que *empezar es 1 lo pone a cero y transmite serie
 * el buffer formateado en ASCII por cada pasada por la función
 */
void enviar_serie(int *temperatura, int *humedad, uint32_t *empezar)
{
	static int estado = 0;
	static int i = 0;
	static char buff[32];
	switch (estado)
	{
	case 0:
		if (*empezar)
		{
			*empezar = 0;
			i = 0;
			sprintf(buff, "<%02d.%01dC;%02d.%01d%%>\r\n", *temperatura / 10,
					*temperatura % 10, *humedad / 10, *humedad % 10);
			huart1.Instance->DR = buff[0];
			estado++;
		}
		break;
	case 1:
		/*
		 * Espero a que se haya terminado de ir un
		 * caracter para transmitir el que sigue.
		 *
		 * El bit a esperar lo saqué del manual del STM32F103C8
		 * https://www.st.com/resource/en/reference_manual/cd00171190-stm32f101xx-stm32f102xx-stm32f103xx-stm32f105xx-and-stm32f107xx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf
		 *
		 */
		if ((huart1.Instance->SR) & (1 << 6))
		{
			/*
			 * Si el caracter es no nulo lo transmito
			 * (para detectar el final del string
			 */
			if (buff[++i])
			{
				huart1.Instance->DR = buff[i];
			}
			else
			{
				/*
				 *
				 * Ya está todo hecho, vuelvo al estado inicial
				 */
				estado = 0;
			}
		}
		break;
	}
}

/*
 * Callback de la interrupción del timer 1.
 * modifiqué el archivo stm32f1xx_hal_timebase_tim.c
 * para que interrumpa cada 10ms.
 * Este ejemplo funciona con un Ts = 10ms.
 *
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == TIM1)
	{
		HAL_IncTick();
		ticks++;
	}
}


void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct =
	{ 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct =
	{ 0 };

	/** Initializes the CPU, AHB and APB busses clocks
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}
	/** Initializes the CPU, AHB and APB busses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
	{
		Error_Handler();
	}
}

static void MX_USART1_UART_Init(void)
{
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 9600;
	huart1.Init.WordLength = UART_WORDLENGTH_9B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart1) != HAL_OK)
	{
		Error_Handler();
	}
}

static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct =
	{ 0 };

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);

	/*Configure GPIO pin : PC13 */
	GPIO_InitStruct.Pin = GPIO_PIN_13;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/*Configure GPIO pin : PB6 */
	GPIO_InitStruct.Pin = GPIO_PIN_6;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

void Error_Handler(void)
{
}
